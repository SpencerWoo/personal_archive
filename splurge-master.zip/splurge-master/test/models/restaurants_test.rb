require 'test_helper'

class RestaurantsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
