require 'test_helper'

class FoodItemsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
