require 'test_helper'

class DineOutTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
