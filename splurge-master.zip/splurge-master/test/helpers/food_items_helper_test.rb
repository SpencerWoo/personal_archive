require 'test_helper'

class FoodItemsHelperTest < ActionView::TestCase
end
