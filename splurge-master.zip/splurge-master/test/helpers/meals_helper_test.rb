require 'test_helper'

class MealsHelperTest < ActionView::TestCase
end
