require 'test_helper'

class DineOutsHelperTest < ActionView::TestCase
end
