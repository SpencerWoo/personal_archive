class AddRestaurantToReservations < ActiveRecord::Migration
  def change
  	change_table :reservations do |t|
      t.foreign_key :restaurants, dependent: :delete
    end
  end
end
