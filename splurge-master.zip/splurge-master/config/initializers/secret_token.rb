# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Splurge::Application.config.secret_key_base = '040aaabf1ee06dba39a7891e79e05ec8b38709274a45cce5f62effd91058a8d6a29dc2334ebbc762922000cb49fbbfd038ca6a60bc57bdbcfca4d503eda7deb8'
