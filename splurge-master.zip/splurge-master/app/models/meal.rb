class Meal < ActiveRecord::Base
	belongs_to :dine_outs
end
