class MenusController < ApplicationController
end
