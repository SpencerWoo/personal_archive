class MealsController < ApplicationController
end
