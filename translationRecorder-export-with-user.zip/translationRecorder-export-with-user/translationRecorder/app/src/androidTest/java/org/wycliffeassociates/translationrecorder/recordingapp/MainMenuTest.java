package org.wycliffeassociates.translationrecorder.recordingapp;

import androidx.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
@LargeTest
public class MainMenuTest {

//    @Rule
//    public ActivityTestRule<MainMenu> mActivityRule = new ActivityTestRule<>(
//            MainMenu.class);
//
//    @Test
//    public void testLaunchAudioFiles() {
//        // Start recording intents
//        Intents.init();
//        // Touch the "new_record" button (the big microphone)
//        onView(withId(R.id.files)).perform(click());
//        // Verify that an Intent was sent to open the Recording Screen
//        Intents.intended(hasComponent(AudioFiles.class.getName()));
//        // Stop recording intents
//        Intents.release();
//    }
//
//    @Test
//    public void testLaunchRecordingScreen() {
//        // Start recording intents
//        Intents.init();
//        // Touch the "new_record" button (the big microphone)
//        onView(withId(R.id.new_record)).perform(click());
//        // Verify that an Intent was sent to open the Recording Screen
//        Intents.intended(hasComponent(RecordingScreen.class.getName()));
//        // Stop recording intents
//        Intents.release();
//    }
//
//    @Test
//    public void testLaunchSettings() {
//        // Start recording intents
//        Intents.init();
//        // Touch the "new_record" button (the big microphone)
//        onView(withId(R.id.settings)).perform(click());
//        // Verify that an Intent was sent to open the Recording Screen
//        Intents.intended(hasComponent(Settings.class.getName()));
//        // Stop recording intents
//        Intents.release();
//    }
}
