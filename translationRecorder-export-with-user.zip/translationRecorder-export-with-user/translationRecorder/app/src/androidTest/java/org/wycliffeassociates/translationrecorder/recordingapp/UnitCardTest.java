package org.wycliffeassociates.translationrecorder.recordingapp;

import android.content.Context;
import androidx.test.InstrumentationRegistry;
import android.test.suitebuilder.annotation.SmallTest;

import org.junit.Before;

/**
 * Created by sarabiaj on 10/2/2017.
 */

@SmallTest
public class UnitCardTest {

    @Before
    public void setUp(){
        Context ctx = InstrumentationRegistry.getContext();
        //UnitCard uc = new UnitCard(ct, Project p, "title", 1, 1);
        //View.OnClickListener ocl = uc.getUnitRecordOnClick(ctx);

    }

}
