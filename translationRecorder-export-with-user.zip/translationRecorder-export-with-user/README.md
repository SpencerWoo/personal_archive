# This Project is Deprecated, for the latest version, please see https://github.com/bible-Translation-Tools/btt-recorder




# translationRecorder

Designed to give mother-tongue oral-only translators a tool for recording scripture audio content, translationRecorder focuses on a simple user interface and high quality recording.

You can get the latest APK from here: [Releases](https://github.com/WycliffeAssociates/translationRecorder/releases) and install it on your Android tablet.

The project was started by a group of interns during "5 Weeks of Code" (which is now [8WeeksOfCode.org](http://8weeksofcode.org)), a program of [Wycliffe Associates](http://wycliffeassociates.org).

Want to contribute? Clone the repo, fire up Android Studio, and submit your pull requests!
